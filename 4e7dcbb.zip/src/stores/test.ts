import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

// pinia测试

export const useCounterStore = defineStore('test', () => {
	const count = ref(0)
	const doubleCount = computed(() => count.value * 2)
	function increment() {
		count.value++
	}

	return { count, doubleCount, increment }
})
