<script lang="ts">
export default { name: 'Home' }
</script>
<script setup lang="ts">

</script>

<template>
	<div>
		首页
	</div>
</template>

<style lang="scss" scoped></style>