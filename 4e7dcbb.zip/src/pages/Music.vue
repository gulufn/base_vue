<script lang="ts">
export default { name: 'Music' }
</script>
<script setup lang="ts">

</script>

<template>
	<div>
		音乐
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
		<h1>测试</h1>
	</div>
</template>

<style lang="scss" scoped></style>